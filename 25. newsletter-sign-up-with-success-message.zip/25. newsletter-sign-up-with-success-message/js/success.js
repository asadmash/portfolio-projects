
const dismissBtn = document.getElementById('dismiss-btn');
dismissBtn.addEventListener('click', () => {
    window.location.href = 'index.html';
});